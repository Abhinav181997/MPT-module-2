package com.capgemini.SpringController;

import java.util.List;



import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.capgemini.ServiceLayer.IProductService;
import com.capgemini.beans.Products;
import com.capgemini.exception.DuplicateProductIdException;
import com.capgemini.exception.ProductNotFoundException;


@RestController
public class ProductController {

	@Autowired
	IProductService productService;									// craeting an object of a service classs

	
	/*
	 * --------------------creating method to send Product JSOn object via POSTMAN using POST request----------------------   
	 */
	@RequestMapping(method = RequestMethod.POST, value = "/addproduct")
	public Products createProduct(@Valid @RequestBody Products products) throws DuplicateProductIdException, ProductNotFoundException {
		return productService.createProduct(products);
	}
	
	

	/*
	 * --------------------creating method to send Product id  using Path variable via POSTMAN using DELETE request----------------------   
	 */
	@RequestMapping(method = RequestMethod.DELETE, value = "/deleteproduct/{id}")
	public Products deleteProduct(@Valid @PathVariable String id) throws ProductNotFoundException {
		return productService.deleteProduct(id);
	}
	
	

	/*
	 * --------------------creating method to list all Products  via POSTMAN using GET request----------------------   
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/viewproducts")
	public List<Products> viewProducts() throws ProductNotFoundException {
		return  productService.viewProducts();
	}
	
	

	/*
	 * --------------------creating method to find the object for the given Product ID by using GET request----------------------   
	 */
	@RequestMapping(method = RequestMethod.GET, value = "/findproduct/{id}")
	public Products findProduct(@Valid @PathVariable String id) throws ProductNotFoundException {
		
		return productService.findProduct(id);
		
	}

	

	/*
	 * --------------------creating method to send Product JSOn object via POSTMAN using PUT request----------------------   
	 */
	@RequestMapping(method = RequestMethod.PUT, value = "/updateproduct/{id}")
	public Products findProduct(@Valid @RequestBody Products products ,@Valid @PathVariable String id) throws ProductNotFoundException {
		return productService.updateProduct(products,id);
	}
}