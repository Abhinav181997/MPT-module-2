package com.capgemini.ServiceLayer;

import java.util.List;
import com.capgemini.beans.Products;
import com.capgemini.exception.DuplicateProductIdException;
import com.capgemini.exception.ProductNotFoundException;

/*
 *  ---------------------------- Declaring Service Class showing all the functinality of the project --------------------------- 
 */
public interface IProductService {

	public Products createProduct(Products products) throws DuplicateProductIdException, ProductNotFoundException;        // to add the new product list

	public Products deleteProduct(String id) throws ProductNotFoundException;											  // to delete existing product information 	
	
	public List<Products> viewProducts() throws ProductNotFoundException;												  // to view the specified product information
	
	public Products findProduct(String id) throws ProductNotFoundException;                                               // to find the product by Product Id 

	public Products updateProduct(Products products, String id) throws ProductNotFoundException;					      // to update the oproduct information 			

	
}
