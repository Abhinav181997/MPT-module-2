package com.capgemini.ServiceLayer;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.capgemini.DAOLayer.IProductRepo;
import com.capgemini.beans.Products;
import com.capgemini.exception.DuplicateProductIdException;
import com.capgemini.exception.ProductNotFoundException;




/*
 * ----------------- Implementing the Interface ProductService by ProductServiceImp ------------------------
 */
@Service
public class ProductServiceImpl implements IProductService {

	@Autowired
	IProductRepo productRepo;					// Creating an object of Product Repo Interface
	
	
	
	/*
	 * ----------------------------overriding the createProduct() method ----------------------------------
	 */
	@Override
	public Products createProduct(Products products) throws DuplicateProductIdException, ProductNotFoundException {
		
		if(productRepo.findById(products.getId()) == null)
			return productRepo.save(products) ;
		else
			throw new DuplicateProductIdException();
	}
	
	
	/*
	 * ----------------------------overriding the deleteProduct() method ----------------------------------
	 */
	@Override
	public Products deleteProduct(String id) throws ProductNotFoundException {
		Products product;
		product = productRepo.findById(id);
		if(product != null) {
			return productRepo.deleteById(product);
		}
		else
			throw new ProductNotFoundException();
	}
		

	
	/*
	 * ----------------------------overriding the viewProducts() method ----------------------------------
	 */	
	@Override
	public List<Products> viewProducts() throws ProductNotFoundException {
		
		List<Products> listProduct= productRepo.findAll();
		if (listProduct.isEmpty()) {
	        throw new ProductNotFoundException();
	    }
		else
			return listProduct;
		
	}
	
	
	
	/*
	 * ----------------------------overriding the findProduct() method ----------------------------------
	 */	
	@Override
	public Products findProduct(String id) throws ProductNotFoundException {
		
		Products product = productRepo.findById(id);
		if(product == null)
			throw new ProductNotFoundException();
		else
			return product;
	}

	
	
	/*
	 * ----------------------------overriding the updateProduct() method ----------------------------------
	 */	
	@Override
	public Products updateProduct(Products products, String id) throws ProductNotFoundException{
		
		Products product = productRepo.findById(id);
		if(product == null)
			throw new ProductNotFoundException();
		else {
			return productRepo.update(product, products);
		}
	}

	}