package com.capgemini.DAOLayer;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.capgemini.beans.Products;
import com.capgemini.exception.DuplicateProductIdException;
import com.capgemini.exception.ProductNotFoundException;

/*
 * ------------- Now declaring a contract by interface,PoductRepo ---------------------- 
 */

@Repository
public interface IProductRepo{

	Products findById(String id) throws ProductNotFoundException;      // to find the delais of product by getting  Product id

	Products save(Products products) throws DuplicateProductIdException, ProductNotFoundException;  // to save the current data

	Products deleteById(Products products) throws ProductNotFoundException;      // to delete product information by getting Product id

	List<Products> findAll() throws ProductNotFoundException;              // to go through the entire database  

	Products update(Products products, Products product) throws ProductNotFoundException;    // to update the Product information  
	
	
	

}