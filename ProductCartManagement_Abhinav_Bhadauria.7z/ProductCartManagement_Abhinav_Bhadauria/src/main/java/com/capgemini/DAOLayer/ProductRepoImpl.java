package com.capgemini.DAOLayer;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.capgemini.beans.Products;
import com.capgemini.exception.DuplicateProductIdException;
import com.capgemini.exception.ProductNotFoundException;


/*
 * ----------------- Implementing the interface ProductRepo by ProductRepoImp ------------------------
 */
@Transactional
@Repository
public class ProductRepoImpl implements IProductRepo{

	@PersistenceContext
	EntityManager entityManager;             		// creating object of EntityManager class
	

	/*
	 * ----------------------------overriding the findById() method ----------------------------------
	 */
	@Override
	public Products findById(String id) throws ProductNotFoundException {
		
		Products product;
		product = entityManager.find(Products.class, id);
		return product;
	}

	
	/*
	 * ----------------------------overriding the save() method ----------------------------------
	 */
	@Override
	public Products save(Products products) throws DuplicateProductIdException, ProductNotFoundException{
		
		entityManager.persist(products);
			return products;
	}

	
	/*
	 * ----------------------------overriding the deleteById() method ----------------------------------
	 */
	@Override
	public Products deleteById(Products product) throws ProductNotFoundException {
		
		entityManager.remove(product);
			return product;
		}

	
	
	/*
	 * ----------------------------overriding the findAll() method ----------------------------------
	 */
	@Override
	public List<Products> findAll() throws ProductNotFoundException {
		
		return entityManager.createQuery("SELECT e FROM Products e", Products.class).getResultList();
	}

	
	
	/*
	 * ----------------------------overriding the update() method ----------------------------------
	 */
	@Override
	public Products update(Products product, Products products) throws ProductNotFoundException {
			product.setName(products.getName());
			product.setModel(products.getModel());
			product.setPrice(products.getPrice());
			return product;
	}
	
	

}
