package com.capgemini.beans;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Positive;
import javax.validation.constraints.Size;


@Entity
@Table(name = "Product")
public class Products {

	@Size( max = 20, message = "id is not valid, id length must be less than 20")           // validations for the id,so value of id can't exceed the size 20 characters
	@NotNull(message = "id can't be null")													// id can not be null becauese it is a primary key
	@Id																						// declaring id as a primary key			
	private String id;
	
	
	@Size( max = 20, message = "Name is not valid, name length must be less than 20")		// validations for the nmae,so value of name can't exceed the size 20 characters
	private String name;
	
	
	@Size( max = 20, message = "model is not valid, model length must be less than 20")		// validations for the model,so value of model can't exceed the size 20 characters
	private String model;
	

	@Positive(message = "price should be positive")											// validating that price should always be positive
	private int price;

	
	
	public String getId()								// getter method for id
	{																		
		return id;
	}

	public void setId(String id)						// setter method for name
	{															
		this.id = id;
	}

	public String getName()								// getter method for name		
	{																
		return name;
	}

	public void setName(String name) 
	{													// setter method for name
		this.name = name;
	}

	public String getModel() {							// geter method for model
		return model;
	}

	public void setModel(String model) 
	{													// setter method for model
		this.model = model;
	}

	public int getPrice() 								// getter method for price		
	{																
		return price;
	}

	public void setPrice(int price)						// setter method for price		
	{
		this.price = price;
	}

	@Override
	public String toString() 							// overriding tostring() method 	
	{
		return "Products [id=" + id + ", name=" + name + ", model=" + model + ", price=" + price + "]";
	}
	
	
	
	
}
